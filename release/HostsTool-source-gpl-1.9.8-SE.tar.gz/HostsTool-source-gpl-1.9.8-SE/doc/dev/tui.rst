.. automodule:: tui.__doc__
    :members:
